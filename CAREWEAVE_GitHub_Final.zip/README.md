# CAREWEAVE — Smart Maternal Health Monitoring Prototype

A self-contained frontend prototype for CAREWEAVE, a smart-textile postpartum monitoring and early-warning concept.

## Run locally
Open `index.html` in a modern browser.

For real Web Bluetooth, use a secure context (HTTPS or localhost) and a browser that supports Web Bluetooth.

## Included
- Premium responsive landing page
- Product selector and sensor hotspots
- Smart textile / sensor matrix
- Clickable system architecture
- Live simulated dashboard
- Stable / Early Warning / Emergency scenarios
- Explainable rule-based risk engine
- Three-tier alerts
- Caregiver and emergency-contact workflow
- Offline-first demo toggle
- Local history and alert storage
- BLE connection interface
- Demo report export
- Mother Mode / Care Team Mode
- 90-second Judge / Presentation Mode
- Safety, privacy and clinical-validation roadmap
- FAQ and contact/demo form
- Dark mode
- Responsive mobile navigation

## Medical safety
CAREWEAVE is presented as a prototype monitoring and early-warning system, not an approved medical device or diagnostic system. Demo thresholds and data are illustrative. Clinical validation and regulatory work are required before clinical use.
